package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Dime un numero");
		int n = teclado.nextInt();
		
		 int contadorPrimos = 0;
	        int i = 2;

	        while (i <= n) {
	            boolean esPrimo = true;
	            int j = 2;

	            while (j < i) {
	                if (i % j == 0) {
	                    esPrimo = false;
	                    break;
	                }
	                j++;
	            }
		
		if (esPrimo) {
                contadorPrimos++;	
	}
	
		i++;	
	        }


	System.out.println("Hay " + contadorPrimos + " números primos entre 1 y " + n);
	
	
	
}
}
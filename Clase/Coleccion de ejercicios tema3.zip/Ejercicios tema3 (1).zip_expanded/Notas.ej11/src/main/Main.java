package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.out.println("Dame 6 notas");
		Scanner teclado = new Scanner(System.in);
		
		int aprobados = 0;
		int condicionado = 0;
		int suspenso = 0;
		
		int contador = 0;
		
		while (contador <6) {
			
		int numero = teclado.nextInt();
			
			if (numero < 4) {
				suspenso++;
			}
			if (numero == 4) {
				condicionado++;;
			}
			if (numero >= 5) {
				aprobados++;;
			}
		contador++;
		
		}
		System.out.println("Alumnos aprobados: " + aprobados);
        System.out.println("Alumnos condicionados: " + condicionado);
        System.out.println("Alumnos suspensos: " + suspenso);
		
		
		
	}
}


		
		
		
	



/**
 * 
 */
/**
 * 
 */
module Pascal.ej14 {
}
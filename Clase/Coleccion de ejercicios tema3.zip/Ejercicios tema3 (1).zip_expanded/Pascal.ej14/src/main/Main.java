package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		
		 Scanner teclado = new Scanner(System.in);
	        System.out.print("Número de filas: ");
	        int filas = teclado.nextInt();

	        for (int n = 0; n < filas; n++) {
	            int num = 1;
	            for (int m = 0; m <= n; m++) {
	                System.out.print(num + " ");
	                num = num * (n - m) / (m + 1);
	            }
	            System.out.println();
	        }
	    }
	}
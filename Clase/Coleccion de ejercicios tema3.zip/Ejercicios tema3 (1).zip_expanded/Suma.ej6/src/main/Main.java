package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
        int minimo = 1;
        int maximo = 100;
        int contador = 0;
        boolean seguir = true;

        while (seguir) {
            int numero1 = (int) (Math.random() * maximo) + minimo;
            int numero2 = (int) (Math.random() * maximo) + minimo;
            int resultadoCorrecto = numero1 + numero2;

            System.out.println("El primer número es: " + numero1);
            System.out.println("El segundo número es: " + numero2);
            System.out.print("Introduce el resultado: ");
            int resultado = teclado.nextInt();

            if (resultado == resultadoCorrecto) {
                System.out.println("¡Correcto!");
                contador++;
            } else {
                System.out.println("Incorrecto. El resultado correcto era: " + resultadoCorrecto);
                seguir = false;
            }
        }

        System.out.println("Has realizado correctamente " + contador + " operaciones.");

    }
}
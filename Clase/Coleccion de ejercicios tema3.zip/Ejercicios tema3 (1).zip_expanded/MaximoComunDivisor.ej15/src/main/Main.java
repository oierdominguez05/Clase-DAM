package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Dime 2 numeros: ");
		int numero1 = teclado.nextInt();
		int numero2 = teclado.nextInt();
		int maximo_comun_divisor = 1;
		int menor = Math.min(numero1,  numero2);
		
		for (int i = menor; i >= 1; i--) { 
            if (numero1 % i == 0 && numero2 % i == 0) {
				maximo_comun_divisor = i;
				break;
			}
		}
		
		
		System.out.println("Maximo_comun_divisor: " + maximo_comun_divisor);
		
		
		
		
		
		
		
		
		
		
		
	}

}

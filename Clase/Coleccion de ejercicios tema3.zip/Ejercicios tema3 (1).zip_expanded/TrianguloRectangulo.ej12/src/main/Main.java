package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		Scanner teclado = new Scanner (System.in);
		System.out.println("Dime un numero");
		int numero = teclado.nextInt();
		
		int i = numero;
		
		while (i > 0) {
			int j = 0;
		while(j < i) {
			System.out.print("*");
		
			j++;
		}	
		System.out.println();
		i--;
	
		}
		
		
		
		
		
	}

}

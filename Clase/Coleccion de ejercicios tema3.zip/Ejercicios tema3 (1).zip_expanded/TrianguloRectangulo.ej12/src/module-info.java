/**
 * 
 */
/**
 * 
 */
module TrianguloRectangulo.ej12 {
}
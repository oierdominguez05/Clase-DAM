package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int suma = 0;
		int numero = 0;
		System.out.println("Dame 10 numeros:");
		Scanner teclado = new Scanner(System.in);
		
		while (numero < 10) {
			suma += teclado.nextInt();
			numero++;
		}
		
		System.out.println("La media es:" + (suma / 10));
		
		
		
		
		
		
		
		
		
	}

}

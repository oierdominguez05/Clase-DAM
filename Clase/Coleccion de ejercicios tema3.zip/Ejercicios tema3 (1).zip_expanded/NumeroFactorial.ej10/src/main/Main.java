package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.out.println("Dime un numero");
		Scanner teclado = new Scanner(System.in);
		int numero = teclado.nextInt();
		
		
		int factorial = 1;
		while ( numero > 1) {
			factorial *= numero;
			numero--;
		}
		
		System.out.println("El resultdo es: " + factorial);
		
		
		
		
	}

}

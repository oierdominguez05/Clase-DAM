/**
 * 
 */
/**
 * 
 */
module NumeroFactorial.ej10 {
}
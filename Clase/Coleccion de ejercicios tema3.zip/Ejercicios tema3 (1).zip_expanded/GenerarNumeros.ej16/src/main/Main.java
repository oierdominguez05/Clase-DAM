package main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int min = 1;
		int max = 100;
		int aleatorio = 0;
		
		while (aleatorio < 90) {
		 aleatorio = (int) (Math.random() * (max - min));	
		System.out.println("Numero generado: " + aleatorio);
		}
		System.out.println("El numero es mayor que 90");
		
		
		
	}

}

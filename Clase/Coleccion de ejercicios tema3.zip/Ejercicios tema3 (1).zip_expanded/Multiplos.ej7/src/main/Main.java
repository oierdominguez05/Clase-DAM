package main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		
		 int i = 7;

	        System.out.println("Múltiplos de 7 menores que 100:");

	        while (i < 100) {
	            System.out.println(i);
	            i += 7;
		
	        }
		
		
		
		
		
		
		
		
		
		
	}

}

package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.out.println("Dame un numero entre 1 y 10");
		Scanner teclado = new Scanner (System.in);
		int numero = teclado.nextInt();
		
		
		if (numero < 1 || numero > 10) {
			System.out.println("No es un numero entre 1 y 10");
		
			
		} else {
			 int contador = 1;
		 while (contador <= 10) {
		            System.out.println(numero + " x " + contador + " = " + (numero * contador));
		            contador++;
		        }
			
		}
			
			
			
			
			
		
		
		
		
		
		
		
	
		
		
		
		
		
		
		
		
	}

}

package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Scanner teclado = new Scanner(System.in);
		long numero = teclado.nextLong();
		String numeroStr = String.valueOf(numero);
		
		
		int contNumSuerte = 0;
		int contNumMalaSuerte = 0;
		
		
		for (int i = 0; i < numeroStr.length(); i++) {
			String digito = numeroStr.substring(i,i+1);
			
			switch(digito) {
			case "3","7","8,","9":
				contNumSuerte++;
				break;
			
			case "0","1","2","4","5","6":
				contNumMalaSuerte++;
				break;
			
			
			}
		}
		
		
		if (contNumSuerte > contNumMalaSuerte) {
			System.out.println("Eres afortunado!");
		} else {
			System.out.println("No eres afortunado!");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("Dime la altura del arbol en centimetros");
		Scanner teclado = new Scanner(System.in);
		double altura = teclado.nextDouble();
		
		double suma = 0;
		double mas_alto = -1; 
		
		double contador = 0;
		double maximo = 0;
		while (altura != -1) {
			suma += altura;
			mas_alto = contador;
		
			contador++;
			altura = teclado.nextDouble();
		if (altura > maximo) {
			maximo = altura;
		
	
		System.out.println("La altura maxima es: " + maximo);
		System.out.println("El numero de arbol es: " + contador);
		teclado.nextDouble();
		
		}
		
		}
		
		
	}

}

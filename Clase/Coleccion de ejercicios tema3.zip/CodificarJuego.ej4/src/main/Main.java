package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int aleatorioEntero = (int) (Math.random() * 100);
		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Dime numeros para intentar adivinar");
		int numeros = teclado.nextInt();
		 while (numeros != -1) {
			 if (numeros > aleatorioEntero) {
				 System.out.println("El numero es menor");
			 }
			 if (numeros < aleatorioEntero) {
				 System.out.println("El numero es mayor");
			 }
			 if (numeros == aleatorioEntero) {
				 System.out.println("Has acertado");
			  teclado.close();
			 }
			 numeros = teclado.nextInt();
		 }
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}

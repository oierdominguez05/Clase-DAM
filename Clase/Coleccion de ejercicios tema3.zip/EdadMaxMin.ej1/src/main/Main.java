package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);

		System.out.println("dime las edades de tu grupo: ");

		int minimo = 0;

	    int maximo = 0;

	    int numero = teclado.nextInt();

	    minimo = numero;

		while (numero != -1) {

			if (numero < minimo) {

				minimo = numero;

			}

		    if (numero > maximo) {

		    	maximo = numero;

		    }
		    numero = teclado.nextInt();
	}

			System.out.println("la edad minima es: " + minimo);

			System.out.println("la edad maxima es: " + maximo);

	}

	}
		
		
		
	


/**
 * 
 */
/**
 * 
 */
module EdadMaxMin.ej1 {
}
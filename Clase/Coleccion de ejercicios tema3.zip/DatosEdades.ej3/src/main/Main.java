package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println("Dime las edades de los alumnos:");
		Scanner teclado = new Scanner(System.in);
		int edad = teclado.nextInt();
		int suma = 0;
		int contador = 0;
		int mayoresDeEdad = 0;
		while (edad >= 0) {
			suma += edad;
			contador++;
			if (edad >= 18) {
			mayoresDeEdad++;	
			
			}
			edad = teclado.nextInt();
		}
		if (contador > 0) {
			System.out.println("Suma de todas las edades" + suma);
			System.out.println("Media: " + (suma / (double)contador));
            System.out.println("Alumnos: " + contador);
            System.out.println("Mayores de edad: " + mayoresDeEdad);
		}
			
		
	
			
			
			
			
			
			
		
		
		
		
		
	}

}

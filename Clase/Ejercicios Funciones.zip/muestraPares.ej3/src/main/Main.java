package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		muestraPares(10);
	}
	
		public static void muestraPares (int n) {
			
				for (int i = 1; i < n; i++) {
					int par = i * 2;
				System.out.println(par);
			}
		
		
		
		
		
		
		
		
		
		
		
	}

}

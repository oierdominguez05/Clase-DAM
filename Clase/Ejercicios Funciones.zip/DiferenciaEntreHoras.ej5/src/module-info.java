/**
 * 
 */
/**
 * 
 */
module DiferenciaEntreHoras.ej5 {
}
package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		System.out.println("Dime la hora 1:");
		System.out.println("Dime los minutos 1:");
		System.out.println("Dime la hora 2:");
		System.out.println("Dime los minutos 2:");
		Scanner teclado = new Scanner(System.in);
		int hora1 = teclado.nextInt();
		int minuto1 = teclado.nextInt();
		int hora2 = teclado.nextInt();
		int minuto2 = teclado.nextInt();
		
		
		
		
		
		
		int resultadoDiferencia = calcularDiferencia (hora1, minuto1, hora2, minuto2);
		if (hora1 < 0 || hora1 > 24 || hora2 < 0 || hora2 > 24 || minuto1 < 0 || minuto1 > 60 || minuto2 < 0 || minuto2 > 60) {
			System.out.println("Valor incorrecto");
		} else {
		
		System.out.println("El resultado es: " + resultadoDiferencia + " minutos");
		}
	}
	public static int calcularDiferencia (int hora1, int minuto1, int hora2, int minuto2) {
		return (int) (hora1 * 60 + minuto1) - (hora2 * 60 + minuto2);
		
	
	}

}

package main;

import java.util.Scanner;

public class Main {

	
	
	
	
	public static void mostrar(int maximo, int minimo, int cantidad) {
	
	for (int i = 0; i < cantidad; i++) {
        int numero = (int)(Math.random() * (maximo - minimo + 1)) + minimo;
        System.out.println(numero);
    }
}

	
	
	
	public static void main(String[] args) {
	
		
		System.out.println("Dime la cantidad de numeros:");
		Scanner teclado = new Scanner(System.in);
		int cantidad = teclado.nextInt();
		int maximo = 1;
		int minimo = 0;
		mostrar(maximo, minimo, cantidad);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}

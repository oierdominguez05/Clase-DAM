package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);

		System.out.println("introducir primer numero: ");

		int numero1 = teclado.nextInt();

		System.out.println("introducir segundo numero: ");

		int numero2 = teclado.nextInt();

		

		if (sonAmigos(numero1,numero2)) {

			System.out.println("los numero introducidos son amigos");

		} else {

			System.out.println("los numero introducidos NO son amigos");

		}

		

	}



	public static boolean sonAmigos(int numero1, int numero2) {

		return sumaDivisores(numero1)== numero2 && sumaDivisores(numero2)== numero1;

	}

		

	/* es lo mismo que: if (sumaDivisores(numero1)== numero2 && sumaDivisores(numero2)== numero1) {

			return true;

		}else {

			return false;*/

		

	

	

	public static int sumaDivisores(int numero) {

		int suma = 0;

		for (int i = 1; i < numero;i++) {

			if (numero %i == 0) {

				suma = suma + i;

			}

			

		}

		return suma;

	}

	

}
	
/**
 * 
 */
/**
 * 
 */
module PositivosAmigos.ej6 {
}
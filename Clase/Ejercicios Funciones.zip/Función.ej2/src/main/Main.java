package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner teclado = new Scanner(System.in);
		System.out.println("Dime el valor de x1:");
		int x1 = teclado.nextInt();
		System.out.println("Dime el valor de y1:");
		int y1 = teclado.nextInt();
		System.out.println("Dime el valor de x2:");
		int x2 = teclado.nextInt();
		System.out.println("Dime el valor de y2");
		int y2 = teclado.nextInt();
		float resultado = resultadoFuncion(x1,y1,x2,y2);
		System.out.println("La distancia Euclidea entre las dos coordenadas introducidas es: " + resultado);
	}
		
		public static float resultadoFuncion(int x1, int y1, int x2, int y2) {
			return (float) Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2,  2));
		
		
		
		
		
		
		
	}

}

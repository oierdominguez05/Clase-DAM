package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		System.out.println("Dime una cantidad de dias: ");
		System.out.println("Dime una cantidad de horas: ");
		System.out.println("Dime una cantidad de minutos: ");
		Scanner teclado = new Scanner(System.in);
		int dias = teclado.nextInt();
		int horas = teclado.nextInt();
		int minutos = teclado.nextInt();
		
		
		int resultadodistancia = segundos(dias, horas, minutos);
		if (dias < 0 || horas > 24 || minutos > 60) {
			System.out.println("Valor incorrecto");
		} else 
		System.out.println("Esto son: " + resultadodistancia + "segundos");
	
		
	}
		public static int segundos (int dias, int horas, int minutos) {
			
			return (int) (dias * 86400 + horas * 3600 + minutos * 60);
		}
		
}
		
		
		
		
		
		
		
		


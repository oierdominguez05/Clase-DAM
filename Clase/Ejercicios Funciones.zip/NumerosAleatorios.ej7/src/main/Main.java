package main;

import java.util.Scanner;

public class Main {

			

		
		public static void mostrar(int cantidad, int minimo, int maximo) {
	        for (int i = 0; i < cantidad; i++) {
	            int numero = (int)(Math.random() * (maximo - minimo + 1)) + minimo;
	            System.out.println(numero);
	        }
	    }

	    public static void main(String[] args) {
	        Scanner teclado = new Scanner(System.in);

	        System.out.print("Cantidad de numeros: ");
	        int cantidad = teclado.nextInt();

	        System.out.print("Valor minimo: ");
	        int minimo = teclado.nextInt();

	        System.out.print("Valor maximo: ");
	        int maximo = teclado.nextInt();

	        mostrar(cantidad, minimo, maximo);
	    }
	}
package main;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		System.out.println("Introduce el radio de la esfera");
		float radio = teclado.nextFloat();
		
		float resultadoSuperficie = calcularSuperficieEsfera(radio);
		float resultadoVolumen = calcularVolumenEsfera(radio);
		
		System.out.println("La superficie de la esfera es: " + resultadoSuperficie);
		System.out.println("El volumen de la esfera es: " + resultadoVolumen);
	}
		public static float calcularSuperficieEsfera(float radio) {
			
		return (float) (4 * Math.PI * Math.pow(radio, 2));
		}
		
		public static float calcularVolumenEsfera(float radio) {
			return(float) (4/3 * Math.PI * Math.pow(radio, 3));
		
		
	}

}

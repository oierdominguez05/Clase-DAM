/**
 * 
 */
/**
 * 
 */
module Vocal.ej5 {
}
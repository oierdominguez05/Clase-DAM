/**
 * 
 */
/**
 * 
 */
module JuegoCalculoMental.ej8 {
}